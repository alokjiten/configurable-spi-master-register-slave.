# Configurable SPI Master with Register-Based SPI Slave

A configurable SPI Master–Slave design implemented in SystemVerilog, with a self-checking testbench and FPGA implementation evidence from Vivado.

## Project Overview

This project integrates an SPI Master, a register-based SPI Slave, and a self-checking SystemVerilog testbench. The Master supports SPI Modes 0–3, a programmable clock divider, 8-bit and 16-bit transfers, full-duplex MOSI/MISO communication, chip-select control, and `start`/`busy`/`done` status. The Slave decodes a 16-bit command and provides register read/write behavior with error reporting.

## Features

- SPI Modes 0, 1, 2, and 3 (CPOL/CPHA)
- Configurable clock divider
- 8-bit and 16-bit Master transfers
- Full-duplex serial data transfer
- Master FSM: `IDLE`, `LOAD`, `TRANSFER`, `FINISH_TRANSFER`, `FINISH`
- `start`, `busy`, `done`, `cs`, and Master error signals
- Register-based SPI Slave with MISO response
- Read-only and read/write register behavior
- Error detection for invalid addresses and malformed transactions
- Self-checking testbench with pass/fail counters
- Vivado resource utilization and timing reports

## Architecture

The top-level module `spi_top.sv` connects `spi_master.sv` and `spi_slave.sv` through `SCLK`, `MOSI`, `MISO`, and active-low chip select `CS`. The testbench also includes controlled scenarios for fault injection and test-model MISO responses.

![SPI system architecture](05_Architecture_and_FSM/architecture_diagram.png)

## SPI Mode Configuration

| SPI Mode | CPOL | CPHA | SCLK idle | Sampling edge |
|---|---:|---:|---|---|
| Mode 0 | 0 | 0 | Low | Rising |
| Mode 1 | 0 | 1 | Low | Falling |
| Mode 2 | 1 | 0 | High | Falling |
| Mode 3 | 1 | 1 | High | Rising |

The mode is selected by `spi_mode[1:0]`.

## Clock Divider

The Master derives SCLK from the system clock using `clock_divider`. For nonzero divider values, the expected nominal relationship is:

\[
f_{SCLK} \approx \frac{f_{clk}}{2 \times clock\_divider}
\]

The testbench exercises divider values 2, 4, and 8 and measures the SCLK period.

## Transfer Width

- `transfer_width = 0`: 8-bit Master transfer
- `transfer_width = 1`: 16-bit Master transfer

The register protocol uses 16-bit transfers.

## 16-bit Register Transaction Format

| Bits | Meaning |
|---|---|
| Bit 15 | Read/write flag: `0` = write, `1` = read |
| Bits 14:8 | 7-bit register address |
| Bits 7:0 | Write data or dummy byte for a read |

Examples:

- `16'h0355`: write `8'h55` to register address `0x03`.
- `16'h8300`: read register address `0x03`; the low byte is a dummy byte.

## Register Map

| Address | Register | Access | Description |
|---|---|---|---|
| `0x00` | Device ID | Read-only | Fixed value `0xA5` |
| `0x01` | Control | Read/write | Control register |
| `0x02` | Status | Read-only | Initialized to `0x01` |
| `0x03` | Data | Read/write | Data register |

The Control and Data registers reset to `0x00`. The Status register resets to `0x01`.

## Master Control FSM

![SPI Master FSM](05_Architecture_and_FSM/master_fsm_diagram.png)

1. **IDLE** — waits for `start` while not busy.
2. **LOAD** — loads transmit data and prepares transfer parameters.
3. **TRANSFER** — shifts MOSI data and samples MISO while generating SCLK.
4. **FINISH_TRANSFER** — completes the final bit and prepares received data.
5. **FINISH** — pulses `done`, clears `busy`, deasserts chip select, and returns to IDLE.

A `start` request while the Master is busy is intended to be ignored.

## Design Files

### RTL
- `01_RTL/spi_master.sv`
- `01_RTL/spi_slave.sv`
- `01_RTL/spi_top.sv`

### Testbench
- `02_Testbench/tb_spi_master_slave.sv`

The testbench connects the DUT, provides controlled test scenarios, and uses pass/fail counters. It includes a simple MISO test model for the 8-bit and clock-divider tests, and a separate slave instance for the incorrect-clock-count test.

## Verification Plan

The supplied testbench includes checks for:

- SPI Modes 0–3
- 8-bit transfer
- Clock divider values 2, 4, and 8
- Back-to-back transactions
- `start` while busy
- Chip-select timing
- Reset during a transaction
- Invalid register address
- Early chip-select deassertion
- Incorrect SPI clock count
- Randomized transactions with a reference model
- MOSI/MISO data ordering

## Reported Verification Result

The project notes supplied with this repository report:

- **Passes:** 83
- **Failures:** 0
- **Reported result:** `ALL MANDATORY SPI TESTS PASSED`

These are the reported results from the supplied testbench run. Re-run the testbench in your own environment before treating the result as independently reproduced.

## FPGA Implementation Evidence

The supplied Vivado screenshots report the following design-level resource counts:

| Resource / metric | Reported value |
|---|---:|
| Slice LUTs | 108 |
| Slice Registers | 125 |
| Bonded I/O | 86 |
| BUFGCTRL | 1 |
| Worst setup slack (WNS) | +5.485 ns |
| Total negative slack (TNS) | 0.000 ns |
| Setup failing endpoints | 0 |
| Worst hold slack (WHS) | +0.132 ns |
| Hold failing endpoints | 0 |
| Worst pulse-width slack | +4.500 ns |

Resource utilization and timing values depend on the selected FPGA part, constraints, tool version, and implementation settings. The values above are transcribed from the provided screenshots and should be rechecked against the final Vivado reports.

### Implementation images

![Vivado utilization](04_Waveforms/Utilization_Report.png)

![Vivado implementation view](04_Waveforms/Implementation_View.png)

![Vivado timing summary](04_Waveforms/Timing_Summary.png)

## Waveform Evidence

The supplied waveforms show the main signals for each SPI mode: `clk`, `rst`, `start`, `tx_data`, `transfer_width`, `spi_mode`, `clock_divider`, `rx_data`, `busy`, `done`, `sclk`, `mosi`, `miso`, `cs`, `master_error`, `slave_error`, and register outputs.

| Mode | Waveform |
|---|---|
| Mode 0 | ![SPI Mode 0](04_Waveforms/SPI_Mode_0.png) |
| Mode 1 | ![SPI Mode 1](04_Waveforms/SPI_Mode_1.png) |
| Mode 2 | ![SPI Mode 2](04_Waveforms/SPI_Mode_2.png) |
| Mode 3 | ![SPI Mode 3](04_Waveforms/SPI_Mode_3.png) |

## Corner Cases

- **Start while busy:** applies another start pulse during an active transfer.
- **Reset during transaction:** checks that the Master returns to idle and chip select is deasserted after reset.
- **Invalid address:** checks Slave error reporting and that defined registers remain unchanged.
- **Early CS deassertion:** checks error reporting for an incomplete transaction.
- **Incorrect clock count:** uses a dedicated test scenario to exercise the Slave's clock-count error handling.

## Limitations

- Master transfer width is limited to 8 or 16 bits.
- The register transaction format is fixed at 16 bits.
- The register map defines four addresses.
- Error indication is implemented; a dedicated timeout counter is not implemented.
- TX/RX FIFOs are not implemented.
- This project is a digital RTL simulation/FPGA implementation exercise; no external physical SPI peripheral is claimed.

## Repository Structure

```text
.
├── 01_RTL/
│   ├── spi_master.sv
│   ├── spi_slave.sv
│   └── spi_top.sv
├── 02_Testbench/
│   └── tb_spi_master_slave.sv
├── 03_Simulation_Log/
│   └── simulation_summary.txt
├── 04_Waveforms/
│   ├── SPI_Mode_0.png
│   ├── SPI_Mode_1.png
│   ├── SPI_Mode_2.png
│   ├── SPI_Mode_3.png
│   ├── Utilization_Report.png
│   ├── Implementation_View.png
│   └── Timing_Summary.png
├── 05_Architecture_and_FSM/
│   ├── architecture_diagram.png
│   └── master_fsm_diagram.png
└── README.md
```

## Tools

- SystemVerilog
- Vivado Simulator (XSim)
- Xilinx Vivado synthesis and implementation reports

## Author

Alok Jiten Rao
